import {HttpClient} from "@angular/common/http";
import {Injectable, OnInit} from "@angular/core";
import {Observable} from "rxjs";
import {Appareil} from "../appareil";
// @ts-ignore
@Injectable()
export class AppareilService implements OnInit{
  appareils : any;
  url : string;
  constructor(private http:HttpClient) {
    this.url = "http://localhost/8080/api/appareils"
  }
  public findAll(): Observable<Appareil[]> {
    return this.http.get<Appareil[]>(this.url);
  }
  switchOnAll() : void {
    for(let appareil of this.appareils) appareil.status="on";
  }
  switchOffAll() : void {
    for(let appareil of this.appareils) appareil.status="off";
  }
  switchOnOne(i : number){
    this.appareils[i].status='on';
  }
  switchOffOne(i : number){
    this.appareils[i].status='off';
  }

  ngOnInit(): void {
    this.findAll().subscribe(data => {
      this.appareils = data;
    });
  }

}
