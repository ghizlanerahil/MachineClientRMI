import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListappareilComponent } from './listappareil.component';

describe('ListappareilComponent', () => {
  let component: ListappareilComponent;
  let fixture: ComponentFixture<ListappareilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListappareilComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListappareilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
