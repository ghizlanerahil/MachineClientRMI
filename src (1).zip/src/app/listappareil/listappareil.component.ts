import { Component, OnInit } from '@angular/core';
import {AppareilService} from "../service/appareilService";

@Component({
  selector: 'app-listappareil',
  templateUrl: './listappareil.component.html',
  styleUrls: ['./listappareil.component.css']
})
export class ListappareilComponent implements OnInit {

  active : boolean = false;
  appareils : any;
  constructor(private appareilService: AppareilService) {
    setTimeout(()=>{
      this.active= true;
    },5000)
  }
  toutAllumer(){
    this.appareilService.switchOnAll();
  }
  toutEteindre(){
    this.appareilService.switchOffAll();
  }

  ngOnInit(): void {
    this.appareilService.findAll().subscribe(data =>
    this.appareils = data);
  }
}
