import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddappareilComponent } from './addappareil.component';

describe('AddappareilComponent', () => {
  let component: AddappareilComponent;
  let fixture: ComponentFixture<AddappareilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddappareilComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddappareilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
