import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addappareil',
  templateUrl: './addappareil.component.html',
  styleUrls: ['./addappareil.component.css']
})
export class AddappareilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
