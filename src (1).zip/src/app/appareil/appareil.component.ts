import {Component, Input, OnInit} from '@angular/core';
import {AppareilService} from "../service/appareilService";

@Component({
  selector: 'app-appareil',
  templateUrl: './appareil.component.html',
  styleUrls: ['./appareil.component.css']
})
export class AppareilComponent implements OnInit {

  @Input() appareilName: String = "";
  @Input() appareilStatus : String = "";
  @Input() id : number = 0;
  constructor(private appService: AppareilService) { }

  switchOne(){
    if (this.appareilStatus === "On"){
      this.appService.switchOffOne(this.id)
    }
    else if (this.appareilStatus === "Off") {
      this.appService.switchOnOne(this.id)
    }
  }
  ngOnInit(): void {
  }

}
