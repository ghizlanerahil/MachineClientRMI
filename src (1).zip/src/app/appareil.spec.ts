import { Appareil } from './appareil';

describe('Appareil', () => {
  it('should create an instance', () => {
    expect(new Appareil()).toBeTruthy();
  });
});
