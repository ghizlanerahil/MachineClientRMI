export class Appareil {
  // @ts-ignore
  id : number;
  name : string = "";
  status : string = "";
}
