import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ListappareilComponent} from "./listappareil/listappareil.component";
import {AddappareilComponent} from "./addappareil/addappareil.component";

const routes: Routes = [
  {path :'appareils' , component : ListappareilComponent},
  {path :'addappareil' , component : AddappareilComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
